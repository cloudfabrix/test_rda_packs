### Overview

This pack contains the following artifacts that are common to the inventory collection packs that depend on them:

- `persistent streams definitions`
- `stack definition for graphdb`
- `relationship maps needed to topology calculation`

These shared components provide foundational functionality and are intended to be reused across multiple inventory collection packs.